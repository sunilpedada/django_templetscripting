from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def values(request):
    return render(request,"values.html")
def add(request):
    try:
        c=request.GET["z"]
        a=int(c)
        d=request.GET["x"]
        b=int(d)
        ref={}
        ref["add"]=a+b
        ref["sub"]=a-b
        ref["div"]=a/b
        ref["mult"]=a*b
        ref["mod"]=a%b
        ref["fdiv"]=a//b
        return render(request,"display.html",{"result":ref})
    except(ValueError):
            return HttpResponse("entered values is not correct")